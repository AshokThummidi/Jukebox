package Exceptions;

public class SongNotFoundException extends Exception {
    public SongNotFoundException(String message){
        super(message);
    }
}
