package Exceptions;

public class AudioNotFoundException extends Exception{
    public AudioNotFoundException(String message){
        super(message);
    }
}
